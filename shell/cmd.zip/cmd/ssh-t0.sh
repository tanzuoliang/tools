#!/bin/bash

./sshpass.sh 22 root 182.254.155.127 tianyiserver888