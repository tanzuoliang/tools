#!/bin/bash

./sshpass.sh 22 root 115.159.214.90 Tianyi2017