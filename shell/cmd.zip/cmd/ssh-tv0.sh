#!/bin/bash

./sshpass.sh 22 root 111.231.113.26 Tianyi2017