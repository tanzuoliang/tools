#!/bin/bash

./sshpass.sh 22 root 192.168.1.240 tywl912