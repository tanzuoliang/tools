# Naming

Only files matching `*_test.rb` will be executed as tests.
