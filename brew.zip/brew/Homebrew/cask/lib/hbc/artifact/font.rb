require "hbc/artifact/moved"

class Hbc::Artifact::Font < Hbc::Artifact::Moved
end
