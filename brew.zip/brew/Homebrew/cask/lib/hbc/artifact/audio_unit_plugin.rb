require "hbc/artifact/moved"

class Hbc::Artifact::AudioUnitPlugin < Hbc::Artifact::Moved
end
