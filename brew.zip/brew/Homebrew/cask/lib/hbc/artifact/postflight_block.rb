require "hbc/artifact/abstract_flight_block"

class Hbc::Artifact::PostflightBlock < Hbc::Artifact::AbstractFlightBlock
end
