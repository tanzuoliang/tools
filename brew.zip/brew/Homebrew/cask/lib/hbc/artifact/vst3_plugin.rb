require "hbc/artifact/moved"

class Hbc::Artifact::Vst3Plugin < Hbc::Artifact::Moved
end
