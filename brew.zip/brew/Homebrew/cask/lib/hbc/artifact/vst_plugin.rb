require "hbc/artifact/moved"

class Hbc::Artifact::VstPlugin < Hbc::Artifact::Moved
end
