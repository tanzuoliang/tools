require "hbc/artifact/moved"

class Hbc::Artifact::Prefpane < Hbc::Artifact::Moved
  def self.artifact_english_name
    "Preference Pane"
  end
end
