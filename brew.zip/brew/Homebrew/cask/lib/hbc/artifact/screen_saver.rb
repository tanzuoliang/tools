require "hbc/artifact/moved"

class Hbc::Artifact::ScreenSaver < Hbc::Artifact::Moved
end
