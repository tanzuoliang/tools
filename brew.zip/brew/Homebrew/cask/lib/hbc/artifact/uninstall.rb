require "hbc/artifact/uninstall_base"

class Hbc::Artifact::Uninstall < Hbc::Artifact::UninstallBase
end
