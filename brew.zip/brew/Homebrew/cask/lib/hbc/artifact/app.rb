require "hbc/artifact/moved"

class Hbc::Artifact::App < Hbc::Artifact::Moved
end
