require "hbc/artifact/moved"

class Hbc::Artifact::Service < Hbc::Artifact::Moved
end
