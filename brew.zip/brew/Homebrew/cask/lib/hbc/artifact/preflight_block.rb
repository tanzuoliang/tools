require "hbc/artifact/abstract_flight_block"

class Hbc::Artifact::PreflightBlock < Hbc::Artifact::AbstractFlightBlock
end
