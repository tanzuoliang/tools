require "hbc/artifact/moved"

class Hbc::Artifact::InputMethod < Hbc::Artifact::Moved
end
