require "hbc/artifact/moved"

class Hbc::Artifact::Colorpicker < Hbc::Artifact::Moved
end
