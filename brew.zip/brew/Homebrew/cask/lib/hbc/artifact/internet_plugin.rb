require "hbc/artifact/moved"

class Hbc::Artifact::InternetPlugin < Hbc::Artifact::Moved
end
