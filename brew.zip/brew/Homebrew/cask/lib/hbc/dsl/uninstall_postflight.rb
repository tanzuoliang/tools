class Hbc::DSL::UninstallPostflight < Hbc::DSL::Base
end
