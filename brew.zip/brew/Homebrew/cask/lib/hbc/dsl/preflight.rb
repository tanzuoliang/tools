class Hbc::DSL::Preflight < Hbc::DSL::Base
  include Hbc::Staged
end
