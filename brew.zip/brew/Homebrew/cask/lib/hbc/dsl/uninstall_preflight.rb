require "hbc/staged"

class Hbc::DSL::UninstallPreflight < Hbc::DSL::Base
  include Hbc::Staged
end
