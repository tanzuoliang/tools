# monkeypatching
require "hbc/extend/hash"
require "hbc/extend/io"
require "hbc/extend/optparse"
require "extend/pathname"
require "hbc/extend/string"
