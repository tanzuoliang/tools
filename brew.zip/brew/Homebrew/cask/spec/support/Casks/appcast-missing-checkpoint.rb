test_cask 'appcast-missing-checkpoint' do
  appcast 'http://localhost/appcast.xml'
end
