test_cask 'sourceforge-version-latest-correct-url-format' do
  version :latest

  url 'https://sourceforge.net/projects/something/files/latest/download'
  homepage 'https://sourceforge.net/projects/something/'
end
