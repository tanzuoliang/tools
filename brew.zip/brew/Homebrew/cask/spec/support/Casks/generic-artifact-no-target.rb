test_cask 'generic-artifact-no-target' do
  artifact 'Caffeine.app'
end
