test_cask 'missing-license' do
  version '1.2.3'

  url 'http://localhost/something.dmg'
end
