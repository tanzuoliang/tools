test_cask 'generic-artifact-relative-target' do
  artifact 'Caffeine.app', target: 'Caffeine.app'
end
