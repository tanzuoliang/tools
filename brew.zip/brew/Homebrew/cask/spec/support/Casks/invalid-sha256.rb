test_cask 'invalid-sha256' do
  version '1.2.3'
  sha256 'not a valid shasum'
end
