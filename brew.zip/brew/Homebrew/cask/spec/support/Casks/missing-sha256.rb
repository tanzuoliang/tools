test_cask 'missing-sha256' do
  version '1.2.3'

  url 'http://localhost/something.dmg'
end
