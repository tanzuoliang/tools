test_cask 'missing-url' do
  version '1.2.3'

  homepage 'http://example.com'
end
