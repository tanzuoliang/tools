test_cask 'version-latest-string' do
  version 'latest'
  sha256 :no_check
end
