test_cask 'missing-name' do
  version '1.2.3'

  url 'http://localhost/something.dmg'
end
