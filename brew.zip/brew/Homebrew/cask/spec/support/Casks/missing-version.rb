test_cask 'missing-version' do
  url 'http://localhost/something.dmg'
  homepage 'http://example.com'
end
