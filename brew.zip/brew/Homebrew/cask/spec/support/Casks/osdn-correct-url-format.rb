test_cask 'osdn-correct-url-format' do
  version '1.2.3'

  url 'http://user.dl.osdn.jp/something/id/Something-1.2.3.dmg'
  homepage 'http://osdn.jp/projects/something/'
end
