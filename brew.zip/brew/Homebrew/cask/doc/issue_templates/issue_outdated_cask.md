Outdated cask: 

* Insert the name of the cask in the title, after the `:`.
* Insert the name of the cask and a link to it in the body of this issue (example: [`alfred`](https://github.com/caskroom/homebrew-cask/blob/master/Casks/alfred.rb)).
* Insert the new version of the app.
* After all that **delete all this pre-inserted template text**.

Failure to follow these instructions may get your issue closed without further explanation. Thank you for taking the time to correctly report the issue.
