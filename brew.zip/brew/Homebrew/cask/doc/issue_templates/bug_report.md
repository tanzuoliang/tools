Bug report:
Remember to follow the [pre bug report](https://github.com/caskroom/homebrew-cask/blob/master/doc/reporting_bugs/pre_bug_report.md) guide beforehand. Failure to do so might get your issue closed.

#### Description of issue

[insert a detailed description of your issue here]

<details><summary>Output of `brew cask <command> --verbose`</summary>

```
[paste output here]
```
</details>

<details><summary>Output of `brew doctor`</summary>

```
[paste output here]
```
</details>

<details><summary>Output of `brew cask doctor`</summary>

```
[paste output here]
```
</details>
