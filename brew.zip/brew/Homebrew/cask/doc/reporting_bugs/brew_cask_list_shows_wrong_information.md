<sup><sub>[Go back](../../README.md#reporting-bugs)</sup></sub>

# `brew cask list` shows wrong information

We know. [`brew cask list` is broken](https://github.com/caskroom/homebrew-cask/issues/14058) and has been for quite a while. Pull requests to fix the outstanding problems are welcome.

**Do not open an issue.**
