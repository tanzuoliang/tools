<sup><sub>[Go back](curl_error_fix_vendor.md)</sup></sub>

This means the issue isn’t in any way related to Homebrew-Cask, but with the vendor or your connection.

Start by diagnosing your connection (try to download other casks, go around the web). If the problem is with your connection, try a website like [Ask Different](https://apple.stackexchange.com/) to ask for advice.

If you’re sure the issue is not with your connection, contact the app’s vendor and let them know their link is down, so they can fix it.

**Do not open an issue.**
