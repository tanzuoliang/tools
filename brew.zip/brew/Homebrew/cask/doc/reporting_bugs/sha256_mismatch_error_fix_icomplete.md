<sup><sub>[Go back](a_cask_fails_to_install.md#sha256-mismatch-error)</sup></sub>

First, lets see if the problem was with your download. Delete the downloaded file (its location will be pointed out right under the `Actual` shasum line) and try again.

If the problem persists, [the cask must be outdated](sha256_mismatch_error_fix_outdated.md).
