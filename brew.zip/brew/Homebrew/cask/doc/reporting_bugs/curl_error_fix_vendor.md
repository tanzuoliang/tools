<sup><sub>[Go back](curl_error_fix_curlrc)</sup></sub>

Lets now see if the issue is upstream:

1. Got to the vendor’s website (`brew cask home {{cask_name}}`).
2. Find the download link for the app and click on it.

Does it download? [Yes](curl_error_fix_outdated.md) | [No](curl_error_fix_wont_fix.md) | [There is nothing to download](curl_error_fix_no_download.md)
