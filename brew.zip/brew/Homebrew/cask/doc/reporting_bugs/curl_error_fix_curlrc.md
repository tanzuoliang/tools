<sup><sub>[Go back](a_cask_fails_to_install.md#curl-error)</sup></sub>

First, lets tackle a common problem: do you have a `.curlrc` file? Those are a frequent cause of issues of this nature. Before anything else, remove that file and try again. If it now works, do not open an issue. Incompatible `.curlrc` configurations must be fixed on your side.

If, however, you do not have a `.curlrc` or removing it did not work, lets [continue our diagnose](curl_error_fix_vendor.md).
